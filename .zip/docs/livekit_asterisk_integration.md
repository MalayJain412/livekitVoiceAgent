# LiveKit + Asterisk Telephony Integration

## Summary of Work Done So Far

1. **LiveKit Server Setup (Windows)**
   - LiveKit server installed and running locally on port 7880.
   - LiveKit agents installed and working.
   - Next.js frontend connected to LiveKit server successfully.

2. **Asterisk Setup (Linux Server)**
   - Asterisk 20.15.2 installed and running.
   - PJSIP transport configured for UDP on port 5060.
   - Extension 1001 configured and registered (Zoiper client).
   - Extension 2000 configured for future LiveKit SIP agent.
   - Dialplan updated to route calls to 2000:
     ```ini
     exten => 2000,1,NoOp(Call from Zoiper to LiveKit)
      same => n,Dial(PJSIP/2000,30)
      same => n,Hangup()
     ```

3. **Test Verification**
   - `asterisk -rx "pjsip show endpoints"` shows 1001 registered and 2000 available but not yet registered.
   - Dialplan confirmed for 2000.

4. **Attempted SIP Agent using Python `aiosip`**
   - Failed due to Python 3.10 compatibility issues (`MutableMapping`) and outdated API.
   - Attempt to use `pjsua` failed because it's not available prebuilt on PyPI for Windows.

5. **Decision**
   - Using `aiosip` or `pjsua` on Windows is unreliable.
   - Recommended approach: **use Asterisk ARI** to bridge calls to LiveKit AI agent.

---

## Complete Approach & Logic

### Goal
Enable LiveKit AI agent to receive inbound calls from Zoiper/Asterisk and participate in conversation.

### Workflow Logic

1. **Incoming Call Flow:**
   - Zoiper (1001) dials extension `2000`.
   - Asterisk receives call and routes to extension `2000`.
   - Asterisk ARI bridge picks up the call and forwards audio to LiveKit room (`inbound-test`).

2. **LiveKit AI Agent:**
   - Agent joins the LiveKit room `inbound-test`.
   - Agent receives audio from the call via the ARI bridge.
   - Agent generates response audio using TTS.
   - Response audio sent back to Asterisk via ARI.

3. **Reasoning:**
   - Avoids SIP library issues on Windows.
   - ARI handles SIP and RTP natively on Asterisk.
   - LiveKit receives audio via Python worker, allowing AI processing.

### Next Steps

1. Setup Asterisk ARI:
   - Enable `http.conf` and `ari.conf`.
   - Create ARI user with permissions to manage channels.

2. Create Python ARI Worker:
   - Use `asterisk-ari-py` or `ari-py` library.
   - Worker listens for inbound calls to 2000.
   - On call, joins LiveKit room `inbound-test` and bridges audio.

3. Test Call Flow:
   - Dial 2000 from Zoiper.
   - Confirm audio reaches LiveKit room.
   - Confirm AI agent responds.

4. Optimize:
   - Implement VAD, noise cancellation, TTS/ASR in LiveKit agent.
   - Expand to multiple rooms or bidirectional calls if needed.

---

## Architecture Diagram (Mermaid)

```mermaid
flowchart TD
    Zoiper[Zoiper SIP Client 1001]
    Asterisk[Asterisk Server]
    ARI[ARI Python Bridge Worker]
    LiveKit[LiveKit Server]
    AI[AI Voice Agent]
    Frontend[Browser / Frontend App]

    Zoiper -->|SIP Call: UDP 5060| Asterisk
    Asterisk -->|Call Routed to 2000| ARI
    ARI -->|Audio Stream| LiveKit
    LiveKit --> AI
    AI -->|TTS Audio| LiveKit
    LiveKit --> ARI
    ARI -->|SIP Audio| Asterisk
    Asterisk --> Zoiper
    LiveKit --> Frontend
```

### Notes on Architecture

- **Zoiper ↔ Asterisk:** Standard SIP call.
- **Asterisk ↔ ARI:** Python bridge handles call events, media streams.
- **ARI ↔ LiveKit:** Audio forwarded into LiveKit room.
- **LiveKit ↔ AI Agent:** Processes audio, generates responses.
- **Frontend:** Optional, to monitor or join LiveKit room.

## Status & developer note

Most of the ongoing engineering work for this **integration is concentrated on the Asterisk side (ARI setup, dialplan, transports and reliable media bridging)**. Managing and debugging Asterisk (server config, SIP transports, ARI workers, and RTP flow) has become quite time-consuming and is making the project workflow hectic given that **I have no knowledge of Asterisk internals**.

If this is a burden, consider one or more of the following to reduce complexity:

- Delegate Asterisk-specific tasks to a telephony engineer or specialist who is comfortable with SIP/ARI.
- Consolidate testing on a single environment (one Asterisk VM + one LiveKit instance) and automate common verification steps (call scripts, logs extraction).
- Prefer the ARI bridge approach as described above (it centralizes SIP complexity in Asterisk and keeps AI logic in the Python worker), and document exact ARI permissions/roles to simplify onboarding.
- Alternatively, evaluate using a managed SIP/Voice provider (Twilio, Voxbone, etc.) for PSTN ingress if maintaining Asterisk becomes unsustainable.

This note is added so maintainers and collaborators understand the current effort balance and can plan resources or scope accordingly.

---

This architecture ensures **stable inbound telephony integration** without relying on outdated SIP libraries on Windows, while fully leveraging your existing LiveKit AI agent setup.

