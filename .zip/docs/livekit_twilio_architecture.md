# LiveKit + Twilio Telephony Integration Architecture

This document describes how to integrate a **local LiveKit server** with **Twilio** for telephony services using **NGINX** as a reverse proxy. It includes architecture diagrams, requirements, and explanation of each component.

---

## **Requirements**

- **Local Setup:**
  - LiveKit Server (v1.9.1+) running locally
  - Python backend for handling conversation and lead storage
  - React frontend with LiveKit JS SDK
- **Telephony:**
  - Twilio account (for external PSTN calls)
  - SIP trunk / credentials from LiveKit
- **Networking:**
  - NGINX installed for reverse proxy
  - Public domain or ngrok for exposing local server (HTTPS required for Twilio webhooks)
- **Software:**
  - Node.js & NPM
  - Python 3.10+
  - Zoiper (optional for local SIP testing)

---

## **Architecture Overview**

```mermaid
flowchart TD
    subgraph Local
        A[React Frontend] -->|WebRTC| B[LiveKit Server]
        B -->|SIP Trunk| C[Python Backend]
        C --> D[Database Leads/Conversations]
    end

    subgraph Internet
        E[Twilio Cloud] -->|SIP Calls| F[NGINX Reverse Proxy]
    end

    F -->|Forward to| B
    B -->|WebRTC Audio/Video| A
```

### Explanation:

1. **React Frontend**: Users interact with the voice agent via WebRTC in browser.
2. **LiveKit Server**: Handles real-time media rooms, supports SIP ingress/egress.
3. **Python Backend**: Logs conversation events, stores leads, manages AI agent logic.
4. **Database**: Stores conversation transcripts, lead info.
5. **NGINX**: Exposes local LiveKit SIP endpoint publicly for Twilio to send/receive calls.
6. **Twilio**: PSTN service sends calls to LiveKit via the public SIP endpoint.

---

## **Detailed Flow**

```mermaid
sequenceDiagram
    participant User as WebRTC Client
    participant LiveKit as Local LiveKit Server
    participant Backend as Python Backend
    participant DB as Database
    participant NGINX as Reverse Proxy
    participant Twilio as Twilio Cloud

    User->>LiveKit: Join Room
    LiveKit->>Backend: Send conversation events
    Backend->>DB: Store leads/conversation

    Twilio->>NGINX: SIP Call to Public Endpoint
    NGINX->>LiveKit: Forward SIP call
    LiveKit->>User: Connect call to Room (WebRTC)
    LiveKit->>Backend: Store call events
```

### Explanation:
- **WebRTC Clients** connect to **LiveKit** for real-time audio/video.
- **Twilio** sends PSTN calls to the public endpoint.
- **NGINX** forwards the calls to **local LiveKit SIP ingress**.
- **Python Backend** listens to events from LiveKit to store transcripts, leads.

---

## **NGINX Configuration Example**

```nginx
server {
    listen 443 ssl;
    server_name livekit.example.com;

    ssl_certificate /path/to/fullchain.pem;
    ssl_certificate_key /path/to/privkey.pem;

    location /sip {
        proxy_pass http://127.0.0.1:5060;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header Host $host;
    }
}
```

- Exposes **LiveKit SIP** over HTTPS so Twilio can reach it.

---

## **Requirements Summary**

- **Hardware:** Local machine running LiveKit + Python backend
- **Network:** Public HTTPS endpoint (via NGINX or ngrok)
- **Software:** LiveKit server, Python backend, React frontend, NGINX, Twilio account
- **Optional:** Zoiper for local SIP testing

---

This architecture allows **real-time AI voice agents** to interact with both **web clients** and **PSTN callers** via Twilio seamlessly.

---

## Exposing SIP: ngrok, alternatives, and recommendations

Note: recent ngrok plans require a paid subscription to create TCP tunnels (which are needed to expose SIP ports such as 5060/5061). If you are evaluating options for exposing a local LiveKit SIP endpoint for Twilio, here are practical alternatives and recommended approaches.

- Paid ngrok (quickest dev path)
  - Pros: very fast to set up, no server to manage, supports TCP tunneling on paid plans.
  - Cons: ongoing cost for paid plan, limited for production scale.
  - Example (after logging into ngrok and reserving a TCP tunnel):
    ```powershell
    ngrok tcp 5060 --region=us
    ```
    ngrok will print a public address like `tcp://0.tcp.ngrok.io:12345`; configure Twilio to target that host:port (or use an NGINX reverse proxy on a VPS that forwards to your ngrok endpoint).

- VPS / Cloud VM (recommended for staging/production)
  - Pros: single public IP, reliable, full control, easier to get TLS certs and proper firewall rules; no tunneling middleman.
  - Cons: cost of a VM and maintenance overhead.
  - Steps summary:
    1. Provision a small VPS (DigitalOcean, AWS EC2, Linode). Ensure ports 5060 (and RTP range) are reachable.
    2. Install LiveKit on the VPS or run LiveKit locally and use an NGINX reverse proxy on the VPS to forward SIP/TCP to your LiveKit host.
    3. Obtain a domain and TLS certs (Let's Encrypt) and use TLS for SIP if possible.
    4. Configure Twilio SIP Trunk to point to your VPS public IP / domain.

- Self-hosted TCP tunnel (FRP) with a small VPS (low cost middle ground)
  - Pros: you control the relay software, cheaper than fully hosting LiveKit in the cloud, supports arbitrary TCP/UDP forwarding.
  - Cons: requires setting up and securing an FRP server; still needs a small VPS.
  - Example: run frps on a VPS and frpc on the local machine to forward local port 5060.

- Router port forwarding (only when you control a NAT with public IP)
  - Pros: no extra services or cost.
  - Cons: often unreliable, ISP blocks or CGNAT may prevent public exposure; not recommended for production.

Checklist for Twilio / LiveKit SIP integration

- Publicly reachable host: IP or hostname that Twilio can reach.
- Open and correctly forwarded ports: SIP (5060/5061 as needed) and RTP media ranges (make sure firewall/NAT handles RTP).
- TLS for SIP (SIPS) where possible — Twilio supports TLS for SIP.
- Correct NGINX/TCP proxy configuration if you sit a proxy in front of LiveKit.
- Test with a softphone (Zoiper) and Twilio's SIP diagnostics.

Recommended next steps

1. For quick testing: use a paid ngrok TCP tunnel for a few hours to validate end-to-end flow.
2. For any staging or production use: provision a small VPS and either host LiveKit there or use it as a public relay (NGINX or FRP) to your local host.
3. If you'd like, I can add an example NGINX config for SIP/TLS and an FRP guide to this repo, or create a short checklist file `docs/EXPOSE_SIP.md` with step-by-step instructions.

---

End of document.

