# LiveKit token integration (frontend + backend)

This guide explains how to safely mint ephemeral LiveKit JWTs server-side and use them from a Next.js frontend (App Router). It includes exact code snippets you can copy into your frontend project.

What you'll get:
- A server-side API route that signs HS256 LiveKit JWTs using your server's `LIVEKIT_API_SECRET`.
- A client-side pattern for `VoiceAssistant` to fetch a token at connect time and use it with LiveKit.

Important security note: never expose `LIVEKIT_API_SECRET` to the browser. Tokens must be minted server-side.

---

## 1) Server-side: add a token mint route

Add this file to your frontend project (App Router):

Path: `src/app/api/livekit/token/route.ts`

```ts
import { NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'

/**
 * Server-side token mint endpoint for LiveKit.
 *
 * Usage:
 * GET /api/livekit/token?room=myroom
 * Returns: { token: string, identity: string }
 */

export async function GET(req: Request) {
	try {
		const url = new URL(req.url)
		const room = url.searchParams.get('room') || undefined

		const apiKey = process.env.LIVEKIT_API_KEY
		const apiSecret = process.env.LIVEKIT_API_SECRET

		if (!apiKey || !apiSecret) {
			return NextResponse.json(
				{ error: 'LIVEKIT_API_KEY and LIVEKIT_API_SECRET must be set on the server' },
				{ status: 500 },
			)
		}

		const identity = `web-${Math.random().toString(36).slice(2, 9)}`
		const now = Math.floor(Date.now() / 1000)
		const ttl = 60 * 60 // 1 hour

		const payload: Record<string, any> = {
			jti: Math.random().toString(36).slice(2),
			iss: apiKey,
			sub: identity,
			iat: now,
			nbf: now,
			exp: now + ttl,
			grants: {
				video: {
					room_join: true,
					...(room ? { room } : {}),
				},
			},
		}

		const headers = { kid: apiKey }
		const token = jwt.sign(payload, apiSecret, { algorithm: 'HS256', header: headers })

		return NextResponse.json({ token, identity })
	} catch (err: any) {
		console.error('Error minting LiveKit token', err)
		return NextResponse.json({ error: String(err) }, { status: 500 })
	}
}
```

Notes:
- This route runs only on the server and reads `LIVEKIT_API_KEY` and `LIVEKIT_API_SECRET` from the server environment.
- If you use the Pages Router (`pages/api`), adapt the handler to `export default function handler(req, res) { ... }`.
- Install dependency in your frontend project:

```bash
npm install jsonwebtoken
# optional types
npm i -D @types/node @types/jsonwebtoken
```

---

## 2) Client-side: update `VoiceAssistant` to fetch a token

Edit `src/components/voice-assistant.tsx` (client component). Replace static token usage with a fetch to the server route before connecting.

Key changes inside the component:

```tsx
'use client'
import React, { useState } from 'react'
import { LiveKitRoom } from '@livekit/components-react' // or import Room from livekit-client if you use lower-level API

export function VoiceAssistant() {
	const [isConnected, setIsConnected] = useState(false)
	const [roomName, setRoomName] = useState('playground-M8v5-wORy')
	const [token, setToken] = useState<string | null>(null)

	const serverUrl = process.env.NEXT_PUBLIC_LIVEKIT_URL || 'ws://localhost:7880'

	async function fetchToken(room?: string) {
		const q = room ? `?room=${encodeURIComponent(room)}` : ''
		const res = await fetch(`/api/livekit/token${q}`)
		if (!res.ok) {
			const err = await res.json().catch(() => ({}))
			throw new Error(err?.error || `Failed to get token: ${res.status}`)
		}
		const data = await res.json()
		return data.token as string
	}

	async function handleConnect() {
		try {
			const t = await fetchToken(roomName)
			setToken(t)
			setIsConnected(true)
		} catch (err) {
			console.error('Failed to fetch token', err)
		}
	}

	function handleDisconnect() {
		setIsConnected(false)
		setToken(null)
	}

	return (
		<div>
			<input value={roomName} onChange={(e) => setRoomName(e.target.value)} />
			<button onClick={handleConnect}>Connect</button>
			<button onClick={handleDisconnect}>Disconnect</button>

			{isConnected && token && (
				<LiveKitRoom serverUrl={serverUrl} token={token} connect={true}>
					{/* Room UI */}
				</LiveKitRoom>
			)}
		</div>
	)
}
```

Notes:
- `fetchToken()` calls your server route to mint a short-lived JWT. The client never sees the secret.
- Use `NEXT_PUBLIC_LIVEKIT_URL` for the client-side LiveKit server URL (set in `.env.local`).

---

## 3) Environment variables and where to put them

- Server-only (never commit): set these in your frontend server environment or `.env.local` for local dev (do NOT prefix with NEXT_PUBLIC_):
	- LIVEKIT_API_KEY=APIntavBoHTqApw
	- LIVEKIT_API_SECRET=pRkd16t4...   # keep secret

- Client-visible (safe to expose):
	- NEXT_PUBLIC_LIVEKIT_URL=ws://localhost:7880

PowerShell example (development session):

```powershell
$env:LIVEKIT_API_KEY = 'APIntavBoHTqApw'
$env:LIVEKIT_API_SECRET = 'pRkd16t4...'
$env:NEXT_PUBLIC_LIVEKIT_URL = 'ws://localhost:7880'
npm run dev
```

If you prefer `.env.local` for Next dev, add the keys there and **do not commit** that file.

---

## 4) Test flow (end-to-end)

1. Start LiveKit server (you already did).
2. Start the frontend dev server with the server envs set.
3. Open the page and click Connect. `VoiceAssistant` calls `/api/livekit/token?room=...`, gets the JWT and connects.

Manual token validate example (PowerShell):

```powershell
# Obtain token from your app
$tok = (Invoke-RestMethod "http://localhost:3000/api/livekit/token?room=playground-M8v5-wORy")
#Invoke-WebRequest -Uri "http://localhost:7880/rtc/validate?access_token=$($tok.token)" -UseBasicParsing -Method GET
```

---

## 5) Optional improvements and production notes

- Scope tokens narrowly: issue tokens per-room and with short TTLs.
- Add authentication/authorization on `/api/livekit/token` so only allowed users can mint tokens for specific rooms.
- Rotate keys and keep secrets in a secret manager (KMS, Vault, Vercel secrets, etc.).
- If you cannot add `jsonwebtoken` to your frontend project, run token generation on your existing backend service (Python/Go) and expose a protected endpoint there instead.

---

## 6) Files to add/edit summary

- Add: `src/app/api/livekit/token/route.ts` (server route that signs tokens) in your frontend project.
- Edit: `src/components/voice-assistant.tsx` — replace static token usage with a call to `/api/livekit/token?room=...`.
- Env: Set `LIVEKIT_API_KEY` and `LIVEKIT_API_SECRET` on server; set `NEXT_PUBLIC_LIVEKIT_URL` for client.

If you want, I can generate the exact patch for your frontend repo (if you provide the path) or add a small `validate_token.ps1` helper in this repo to generate/validate tokens quickly.

---

If you'd like me to create the server route inside your frontend directory or add the validate helper script here, tell me which and I'll apply the change.
