## Friday - Repo architecture: high-level and micro-level

This document describes the repository architecture at both high-level and micro-level. It explains why components exist, when and where they run, how data moves between them, and documents important functions with inputs, outputs, flows and error modes. The goal is a single reference for developers onboarded to this repo.

> Assumptions
- The repository follows the conventions described in `backup_plugin_modifications/` and the quick-start in `cagent.py`/`model/*`.
- User-facing messages are mostly Hinglish. Lead JSON fields must be English: `name`, `email`, `company`, `interest`, `phone`, `budget`.

## 1. High-level architecture (components)

Overview: this project is an agent that supports hybrid (JSON + RAG) responses, lead detection & capture, conversation logging, and optional voice plugins. Major runtime roles:

- Entrypoint / session manager: `cagent.py` — sets up AgentSession, loads plugins (TTS/STT), initializes conversation logging, orchestrates tools.
- Business logic tools: `tools.py` — core tool functions used by the agent (product lookup, lead creation, intent detection).
- Prompts & conversation rules: `prompts.py` — system & user prompts, lead capture phrasing (Hinglish), message templates.
- Config & logging helpers: `config.py` — paths, helpers to create conversation logs and lead files.
- RAG / knowledge base: `model/` — build and run RAG (Chroma DB, embeddings, run API), includes `build_db.py` and `runapi.py`.
- Plugins and runtime extensions: `backup_plugin_modifications/`, `custom_plugins/`, `testing_plugins/`, `downloaded_package/` — plugin code and modified stubs (LiveKit, TTS) to support integrations.
- Conversations & leads persistence: `conversations/` and `leads/` — persistent JSON records created at runtime.
- Tests and scripts: test files at repo root for sanity checks and examples (`test_*.py`).

Architecture diagram (text):

User (chat/voice)
  -> cagent.py (AgentSession)
      -> prompts.py (system prompt + rules)
      -> tools.py (function tools)
          -> triotech_info (fast JSON lookup) -> data/ or model/runapi.py (RAG)
          -> create_lead -> config.py -> leads/*.json
          -> detect_lead_intent -> tools flow
      -> plugins (TTS/STT, LiveKit) -> backup_plugin_modifications/
  -> conversations/*.json logging

## 2. Directory structure (snapshot)

Top-level (important folders/files):

```
all_code_snippets_frontend.txt
all_code_snippets.txt
ARCHITECTURE_IMPORT_MAPPING.md
cagent.py
config.py
CONVERSATION_LOGGING_JSON_IMPLEMENTATION.md
copy_utils.py
DOCKER_DEPLOYMENT_GUIDE.md
docker-compose.yml
Dockerfile
generate_livekit_token.py
prompts.py
README.md
requirements.txt
test_dummy_plugins.py
test_lead_detection.py
test_triotech_assistant.py
tools.py
backup_plugin_modifications/
  cartesia_tts_modified.py
  google_llm_modified.py
  README.md
conversations/
  conversation_YYYYMMDD_HHMMSS.json (many)
custom_plugins/
data/
docker_scripts/
docs/
downloaded_package/
friday-frontend/
KMS/
leads/
model/
rag_backend/
testing_plugins/
```

Note: many conversation files exist in `conversations/` — these are created by runtime logging.

## 3. Component-level descriptions and responsibilities

### cagent.py
- Purpose: application entrypoint and session orchestration.
- Why: central place to wire agent session, plugins, logging, and start conversation loop (voice or text).
- Typical runtime: invoked by developer or container, e.g. `python cagent.py`.
- Key responsibilities:
  - Call `config.setup_conversation_log()` to create a per-run conversation JSON file (naming: `conversation_YYYYMMDD_HHMMSS.json`).
  - Initialize AgentSession (holds conversation state, registered tools, plugins).
  - Register tool functions from `tools.py` (decorator-managed) so the agent can call them.
  - Manage plugin lifecycle (TTS/STT or LiveKit) and route audio/text through plugins when used.
  - Graceful shutdown and log flush.

### tools.py
- Purpose: core business logic; each function is exposed to the agent via a decorator pattern like `@function_tool()`.
- Why: keep agent-usable operations (answer retrieval, lead creation, intent detection) in one place for testability.
- Typical functions (concrete examples):
  - triotech_info(query: str) -> str
    - Inputs: free-text query
    - Outputs: Hinglish string response (short) or call to RAG for longer responses
    - Flow: check `data/` JSON files for a product name match; if match and query is not deep, return JSON snippet; if query includes words like `features|how to|api|integrate`, call model/runapi.py for RAG.
    - Error modes: no product found -> return small Hinglish error message; RAG timeout -> fallback to JSON or a polite Hindi message.

  - create_lead(name: str, email: str, company: str, interest: str, phone: Optional[str]=None, budget: Optional[str]=None) -> str
    - Inputs: required fields `name`, `email`, `company`, `interest`. Optional `phone`, `budget`.
    - Outputs: Hinglish confirmation string and writes `leads/lead_YYYYMMDD_HHMMSS.json` containing English keys: `name`, `email`, `company`, `interest`, `phone`, `budget`.
    - Flow: validate required fields, validate email format, sanitize strings, check for duplicates (optional), write JSON using helpers in `config.py`.
    - Error modes: missing required field -> return small Hindi error; invalid email -> request for corrected email; IO error -> return Hindi error + log to stderr.

  - detect_lead_intent(text: str) -> dict or str
    - Inputs: incoming user text
    - Outputs: detection result (Hinglish string or structured object) indicating whether this is a lead and what fields can be extracted.
    - Flow: rule-based + heuristics (phone/email regex, keywords like `interested`, `price`, `demo`), optionally call the RAG backend for ambiguous cases.
    - Error modes: ambiguous detection -> return a follow-up question in Hinglish requesting clarification.

### prompts.py
- Purpose: central place for system and user prompt templates. Contains Hinglish templates for lead confirmations and rules.
- Why: keeps language and rules consistent across the agent, unit-tests, and plugins.

### config.py
- Purpose: configuration helpers, path helpers, and conversation logging utilities.
- Key functions:
  - `setup_conversation_log()` -> str/path: creates a new file under `conversations/` and returns path.
  - helpers to save leads and to build consistent filenames like `lead_YYYYMMDD_HHMMSS.json`.

### model/
- Purpose: RAG (retrieval-augmented generation) support and vector DB build & runtime.
- Files of interest: `model/build_db.py`, `model/runapi.py`.
  - `build_db.py`:
    - Chunks source docs (recommended chunk_size=1500, overlap=200) and builds a persistent Chroma DB under `model/chroma_db/`.
    - Uses HuggingFace embeddings in the current conventions.
  - `runapi.py`:
    - Small API service to query the vector DB and return RAG-augmented answers.
    - Handles API key rotation when cloud LLM returns ResourceExhausted.
    - Expected runtime: `python model/runapi.py` to start local RAG API for the agent.

### backup_plugin_modifications/ and docker_scripts/
- Purpose: patched plugin stubs (LiveKit, TTS) that are applied to container/plugin installs via `docker_scripts/apply_modifications.py`.
- Why: deterministic plugin behavior inside containerized deployments.

## 4. Data models and JSON schemas

- Conversation log JSON (per-run):
  - filename: `conversations/conversation_YYYYMMDD_HHMMSS.json`
  - example fields: timestamped entries of {role: "user|assistant|tool", text: str, meta: {...}}

- Lead JSON (per lead):
  - filename: `leads/lead_YYYYMMDD_HHMMSS.json`
  - shape (keys MUST be English):
    {
      "name": "Full Name",
      "email": "someone@example.com",
      "company": "Acme Ltd",
      "interest": "product or service",
      "phone": "+911234567890",
      "budget": "<optional budget text>",
      "created_at": "ISO8601 timestamp"
    }

## 5. Function catalog (important functions, inputs, outputs, flow)

Below are compact contracts for the most important functions; these are intentionally precise so tests and callers can rely on them.

- setup_conversation_log() -> str
  - Inputs: none
  - Outputs: path to new conversation JSON file
  - Side effects: creates `conversations/` dir entry if needed and writes an initial JSON structure.

- triotech_info(query: str) -> str
  - Inputs: `query` text
  - Outputs: a Hinglish string with the best short answer or a longer RAG answer
  - Failure modes: If no match, returns a short Hinglish message suggesting clarifying questions.

- create_lead(name, email, company, interest, phone=None, budget=None) -> str
  - Inputs: fields described above
  - Outputs: Hinglish confirmation; writes a lead JSON file to `leads/`
  - Validations: email regex check; required fields present

- detect_lead_intent(text: str) -> dict
  - Inputs: user text
  - Outputs: structured dict like {is_lead: bool, fields: {name?, email?, phone?, company?, interest?, budget?}, confidence: float}
  - Implementation note: often rule-based regex + keyword scoring; fallback to follow-up question at low confidence.

## 6. Flows: end-to-end examples

Example A: User asks product question
1. User -> Agent (via cagent.py session)
2. Agent calls `triotech_info(query)` from `tools.py`.
3. `triotech_info` checks `data/` JSON for quick facts:
   - If found and query is simple, return JSON snippet (Hinglish) and log to conversation file.
   - If query contains deep keywords (features, API, integrate), call RAG via `model/runapi.py` and return longer answer.
4. Agent sends response to user and appends to conversation log.

Example B: User expresses buying interest (lead capture)
1. User message captured in session logs.
2. Agent calls `detect_lead_intent(text)`.
3. If `is_lead=True` and extracted fields meet required set, Agent calls `create_lead(...)`.
4. `create_lead` validates, writes `leads/lead_YYYYMMDD_HHMMSS.json`, and returns a Hinglish confirmation to the user.

## 7. Error handling, edge cases and mitigations

- Missing or invalid lead fields
  - Detection: `create_lead` validates and returns a short Hindi/Hinglish error asking for the missing field.
  - Mitigation: follow-up question templates in `prompts.py`.

- RAG failures (API exhausted / timeout)
  - Detection: `model/runapi.py` catches LLM errors and attempts API key rotation.
  - Mitigation: return shorter JSON-based answer or a fallback message asking to rephrase.

- Plugin (TTS/STT) failures
  - Detection: plugin exceptions logged; agent falls back to text-only mode.
  - Mitigation: `backup_plugin_modifications/` contains patched implementations; `docker_scripts/verify_modifications.py` ensures patches are applied in deployments.

- Concurrency / race conditions writing leads or conversation logs
  - Detection: file write exceptions or corrupted JSON.
  - Mitigation: use atomic write to temp file then rename; acquire a minimal file lock if multi-process expected.

## 8. Quality gates and tests (how to verify changes locally)

Quick local checks (PowerShell-friendly):

```
pip install -r requirements.txt; pip install -r model/requirements.txt
python model/build_db.py  # build RAG DB (if you changed knowledge sources)
python cagent.py          # run the agent
python test_triotech_assistant.py
python test_dummy_plugins.py
python test_lead_detection.py
```

Suggested unit/integration tests to keep green:
- Lead creation: happy path + missing email + invalid email
- triotech_info: product found (fast path) + RAG path
- RAG API: simple query to `model/runapi.py` and expected structured output

## 9. Developer notes: why each choice, when to change it

- Why hybrid JSON + RAG?
  - Fast answers come from a small JSON dataset (low latency and deterministic). RAG is used only for deep, content-rich queries. This reduces cost and latency while retaining depth where needed.

- When to rebuild vector DB?
  - Whenever the knowledge corpus under `data/` (or other documentation) is changed. Run `python model/build_db.py`.

- Where to add new tools?
  - Add in `tools.py` with the `@function_tool()` decorator and keep user-facing strings in Hinglish as per repository convention. Add unit tests under `test_*.py`.

## 10. Minimal onboarding checklist for a new dev

1. Read `cagent.py`, `tools.py`, `prompts.py`, and `config.py`.
2. Run the tests: `python test_triotech_assistant.py` and others.
3. If you need RAG, install `model/requirements.txt` and run `python model/build_db.py`.
4. Start the agent locally: `python cagent.py`.

## 11. Next steps / recommended improvements

- Add explicit unit tests for all public tool functions and their error branches.
- Add schema validators (pydantic/dataclass) for lead and conversation JSON to avoid silent corruption.
- Add atomic file-writes and simple file locks for `leads/` and `conversations/` to protect against concurrent processes.
- Add CI checks: linting (flake8/ruff), type-checking (mypy) and test runner.

## 12. Closing summary

This document collected high-level components, concrete function contracts, data models, flows and recommended quality gates. It should serve as the single source of truth for developers who want to understand why components exist, when they run, where they live on disk and how they interact. For additions or modifications, extend the relevant sections and add tests that validate the contracts listed here.

If you want, I can:
- generate a UML sequence for a specific flow (lead capture / triotech_info).
- add pydantic models for leads and conversation logs and wire them into `tools.py` and `config.py`.
- create CI config (GitHub Actions) that runs the tests and linters.

## 13. Mermaid diagrams (visual flows)

Below are Mermaid diagrams that visualize the main flows. These can be rendered in GitHub or VS Code Markdown preview that supports Mermaid.

### 13.1 High-level flow

```mermaid
flowchart TD
  User[User] -->|message/audio| CAgent["cagent.py - AgentSession"]
  CAgent --> Prompts["prompts.py"]
  CAgent --> Tools["tools.py - function tools"]
  Tools -->|fast lookup| Data["data/ JSON"]
  Tools -->|deep query| RAG["model/runapi.py (RAG API)"]
  Tools --> Leads["leads/ (create_lead)"]
  CAgent --> Plugins["Plugins (TTS/STT / LiveKit)"]
  CAgent --> Conversations["conversations/ (logging)"]
  RAG --> ModelChroma["model/chroma_db"]
  Plugins -->|audio| STT["STT"]
  Plugins -->|audio| TTS["TTS"]
```

### 13.2 triotech_info flow (fast path vs RAG)

```mermaid
sequenceDiagram
  participant U as User
  participant A as Agent (cagent.py)
  participant T as tools.triotech_info
  participant D as data/ JSON
  participant R as model/runapi.py (RAG)
  U->>A: "Tell me about Product X"
  A->>T: triotech_info(query)
  T->>D: try fast JSON lookup
  alt found & simple
    D-->>T: JSON snippet
    T-->>A: short Hinglish answer
  else deep or keywords
    T->>R: call RAG API
    R-->>T: long RAG-augmented answer
    T-->>A: return RAG answer
  end
  A-->>U: respond (Hinglish)

```

### 13.3 Lead capture flow

```mermaid
flowchart TD
  U[User] -->|"I'm interested, can I get a demo?"| A(Agent)
  A --> DLI[detect_lead_intent_text]
  DLI -->|is_lead=True, fields extracted| CL[create_lead_in_tools_py]
  CL -->|validates| CFG[config.save_lead -> leads/lead_timestamp.json]
  CL -->|returns| A
  A -->|confirmation Hinglish| U
  DLI -->|low_confidence| A2[Agent asks follow-up Hinglish]
  A2 --> U
```

### 13.4 Plugin audio flow (STT/TTS & LiveKit)

```mermaid
flowchart LR
  Microphone -->|audio| LiveKit[LiveKit / Inbound]
  LiveKit -->|forward| Agent
  Agent -->|send audio to| STT
  STT -->|text| Agent
  Agent --> Tools
  Tools -->|text response| Agent
  Agent -->|send text to| TTS
  TTS -->|audio| LiveKit[LiveKit / Outbound]
  LiveKit -->|audio playback| Speaker
```

### 13.5 RAG build & query flow

```mermaid
flowchart TB
  Sources[data/docs/knowledge] --> Chunker[build_db.py chunker]
  Chunker --> Embeddings[HuggingFace embeddings]
  Embeddings --> Chroma[Chroma DB - model/chroma_db]
  Chroma --> runapi[model/runapi.py]
  runapi -->|query| Chroma
  runapi -->|LLM| LLM[LLM provider]
  runapi --> Agent
```

#### Rendering notes
- GitHub's Markdown renderer supports Mermaid diagrams in repositories with a feature flag (or when using GitHub Pages / other renderers). VS Code's Markdown preview supports Mermaid if you have the Mermaid plugin or built-in support in newer versions.

If you'd like, I can also generate PNG/SVG exports of these diagrams and add them to `docs/`.
