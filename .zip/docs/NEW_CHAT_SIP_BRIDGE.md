# New Chat — LiveKit SIP Bridge Approach

Purpose: a single, copy-pasteable reference to get a new voice-chat (SIP → LiveKit → AI agent) flow running locally or on a small staging host. Use this while Go is installing or as the checklist before you build the SIP bridge.

Files referenced in this repo:
- `cagent.py` — Python voice agent that joins LiveKit rooms and runs STT/LLM/TTS.
- `sip_agent.py` — earlier attempt at a SIP client bridge (kept for reference).
- `livekit_twilio_architecture.md` — higher-level architecture for Twilio exposure.

## 1. Architecture (high level)

flowchart LR
    ZOIPER[Zoiper SIP Client] -->|SIP Invite| SIP_BRIDGE[LiveKit SIP Bridge]
    SIP_BRIDGE -->|RTP / WebRTC| LIVEKIT[LiveKit Server]
    LIVEKIT -->|Room Audio| AGENT[Python Voice Agent (`cagent.py`)]
    AGENT -->|TTS / Audio| LIVEKIT
    LIVEKIT -->|WebRTC / RTP| SIP_BRIDGE
    SIP_BRIDGE -->|Audio Back| ZOIPER

Explanation:
- A SIP client (Zoiper / Asterisk) calls a SIP user exposed by the SIP Bridge.
- The SIP Bridge handles SIP signaling + RTP; it creates/joins a LiveKit room and forwards RTP into LiveKit (and back out to SIP).
- The Python voice agent (`cagent.py`) joins the LiveKit room, performs STT → LLM → TTS, and plays audio back into the room.

This approach avoids building your own RTP ↔ WebRTC media plumbing. The SIP Bridge (Go binary in this repo) already implements the hard part.

## 2. Components & prerequisites

- LiveKit server (local or remote). Example default: `ws://localhost:7880`.
- Redis server (127.0.0.1:6379) — used by the SIP Bridge for call state.
- LiveKit SIP Bridge (this repo's `cmd/sip` binary).
- Python 3.10+ environment for `cagent.py` (STT/TTS libs, env vars).
- A SIP softphone for testing (Zoiper / Linphone).
- (Optional) A small VPS or NAT with port forwarding if you need external PSTN exposure.

Local development machine notes
- Windows: use WSL for Go and Redis if you prefer a Linux-like environment; Redis for Windows exists but WSL is recommended.
- Linux/macOS: native install of Go and Redis is straightforward.

## 3. Quick checklist (before you start)

1. LiveKit server running and reachable at `ws://localhost:7880` or a configured host.
2. Redis running on `127.0.0.1:6379`.
3. You have a LiveKit API key and secret (don't commit these anywhere).
4. `go` toolchain available to build the SIP bridge (or use a pre-built binary).
5. `cagent.py` environment configured for LiveKit (see section 6).

## 4. Sample `sip-config.yaml` (copy to `scripts/sip-config.yaml` locally)

```yaml
# Minimal sip bridge config. Keep secrets out of Git.
log_level: debug

# LiveKit credentials (replace with env or local-only file)
api_key: "<LIVEKIT_API_KEY>"
api_secret: "<LIVEKIT_API_SECRET>"
ws_url: "ws://localhost:7880"

redis:
  address: "127.0.0.1:6379"

# SIP / RTP ports
sip_port: 5060
rtp_port: "10000-20000"

# Optional binds
bind_address: "0.0.0.0"
```

Notes:
- Keep `api_secret` local and do not check into Git. Use environment variables or a secrets file.

## 5. Build & run the SIP Bridge

PowerShell (Windows) or bash (Linux/WSL). Replace the config path as appropriate.

PowerShell / WSL commands:
```powershell
git clone https://github.com/livekit/sip.git
cd sip
go build -o livekit-sip ./cmd/sip
./livekit-sip --config ../scripts/sip-config.yaml
```

Linux (bash):
```bash
git clone https://github.com/livekit/sip.git
cd sip
go build -o livekit-sip ./cmd/sip
./livekit-sip --config ../scripts/sip-config.yaml
```

If `go` is not yet installed: you can still prepare `scripts/sip-config.yaml` and `scripts/run_sip_bridge.ps1` (or `run.sh`) while waiting for Go.

## 6. Configure the Python voice agent (`cagent.py`)

Update your `.env` or environment with these minimal values (do not commit `.env`):

```env
LIVEKIT_URL=ws://localhost:7880
LIVEKIT_API_KEY=<LIVEKIT_API_KEY>
LIVEKIT_API_SECRET=<LIVEKIT_API_SECRET>
# Optional: LLM model selection
LLM_MODEL=gemini-2.5-flash
```

`cagent.py` (in this repo) is already set up to read env variables. Make sure to run in the same environment where the vars are present.

Start the agent:
```bash
python cagent.py
```

## 7. Zoiper / SIP client configuration (testing)

- Host: IP address of the machine running the SIP Bridge (or `127.0.0.1` if local)
- Username: `sipuser` (or whichever user the SIP Bridge advertises — confirm bridge docs)
- Password: `sipsecret` (if the bridge uses static credentials)
- Port: 5060, Transport: UDP
- Codecs: Opus, PCMU (ulaw) — prefer PCMU (ulaw) for simple RTP bridging

Test flow:
1. Start Redis.
2. Start LiveKit server.
3. Start SIP Bridge.
4. Start `cagent.py`.
5. From Zoiper, call the SIP user configured in the bridge. Bridge logs should show INVITE -> join -> RTP forwarding.

## 8. Verification checklist

- SIP Bridge logs show `INVITE` and `RTP` port allocations.
- LiveKit room shows an extra participant representing the SIP caller.
- `cagent.py` logs show STT input and LLM replies and TTS playback events.
- Audio loop: speaker (caller) → LiveKit → agent → LiveKit → SIP Bridge → caller.

If audio is silent:
- Confirm codec compatibility (PCMU/ulaw vs opus). Force ulaw on both ends for a simple test.
- Check RTP port ranges and firewall / NAT settings.
- Run a softphone (Zoiper) and record RTP with `tcpdump` or use LiveKit diagnostics.

## 9. Troubleshooting tips

- "Registration failed" or "Unreachable": ensure Redis and SIP Bridge running and that the SIP client is using the bridge host/port.
- "No audio": common causes — codec mismatch, RTP ports blocked, or bridge not forwarding media. Temporarily enable debug logs in the SIP bridge and LiveKit.
- "TTS not heard": ensure `cagent.py` TTS backend is healthy and the agent is connected to the same room as the SIP bridge participant.

Useful debug commands
- Test Redis: `redis-cli -h 127.0.0.1 ping` (should return `PONG`).
- Confirm port listening (Linux): `ss -tulpn | grep 5060` or `sudo lsof -i :5060`.

## 10. Security & production notes

- Do not expose LiveKit API secret or Redis without firewall restrictions.
- For production, run the SIP Bridge on a small VPS with a proper firewall and TLS where possible.
- If you need PSTN connectivity, prefer Twilio SIP Trunk or a SIP provider; for local testing use ngrok TCP (paid), or use a VPS instead.

## 11. Optional next steps I can implement for you

1. Add `scripts/sip-config.yaml` and `scripts/run_sip_bridge.ps1` + `scripts/run_sip_bridge.sh` to this repo (local-only configs, not checked in with secrets).
2. Provide a `docker-compose.yml` snippet that runs Redis + (optionally) an already-built `livekit-sip` container for quick testing.
3. Add a small `docs/EXPOSE_SIP.md` with ngrok/FRP/VPS instructions and sample NGINX TLS config.
4. Add a sample Asterisk `extensions.conf` snippet to route calls into the SIP Bridge (Stasis or trunking) for advanced testing.

Tell me which one you want and I will create the files and tests for it.

---

End of document.
