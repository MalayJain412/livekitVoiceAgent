# Friday AI Assistant – Triotech Sales & Query Platform

## Overview
Friday AI is a hybrid sales and query assistant for Triotech Bizserve Pvt. Ltd., combining static JSON knowledge and advanced RAG (Retrieval-Augmented Generation) using LangChain and ChromaDB. It supports lead capture, product info, and detailed business queries via a unified backend and web interface.

---

## Architecture

**Hybrid Knowledge System:**
- **Static JSON:** Fast lookup for basic product info, FAQs, and differentiators (`data/triotech_content.json`).
- **RAG (Retrieval-Augmented Generation):** Uses vector database (ChromaDB) and LLMs for detailed, technical, or workflow queries (`data/triotech_knowledge.txt`, `data/knowledge.txt`).

**Directory Structure:**
- `tools.py` – Hybrid query logic, lead detection, and creation
- `model/build_db.py` – Vector store builder for RAG
- `model/runapi.py` – Flask API for RAG queries and web chat
- `data/` – Knowledge files and JSON content
- `model/chroma_db/` – Persisted vector database
- `model/templates/index.html` – Web chat UI
- `ARCHITECTURE_IMPORT_MAPPING.md` – Import mapping and migration guide

**Environment:**
- Python 3.10+
- Flask, LangChain, ChromaDB, Google Gemini LLM, HuggingFace Embeddings
- Docker and venv support
- All API keys and secrets in `.env`

---

## Key Functionalities

- **Hybrid Query Handling:**
  - Basic queries answered from static JSON
  - Detailed queries routed to RAG system
- **Lead Detection & Capture:**
  - Detects business intent, captures leads with required info
- **Web Search & Weather:**
  - DuckDuckGo search and weather info via tools
- **Web Chat UI:**
  - Modern frontend for user interaction
- **Import Structure:**
  - All RAG/model imports use `model/` prefix
  - Knowledge files accessed from `data/`

---

## Setup & Installation

1. **Clone the repository:**
   ```sh
   git clone <repo-url>
   cd Friday-AI
   ```
2. **Install dependencies:**
   ```sh
   pip install -r requirements.txt
   pip install -r model/requirements.txt
   ```
3. **Configure environment:**
   - Edit `.env` with your API keys (see sample in repo)
4. **Build the vector store:**
   ```sh
   python model/build_db.py
   ```
5. **Run the backend API:**
   ```sh
   python model/runapi.py
   ```
6. **Access the web UI:**
   - Open `http://localhost:5000` in your browser

---

## Usage

- Ask product questions, request demos, or technical details
- Lead info is captured and saved in `leads/`
- All queries are handled in Hinglish (mix of Hindi and English)
- RAG system provides detailed, context-rich answers

---

## File Mapping & Migration

See `ARCHITECTURE_IMPORT_MAPPING.md` for full details on old vs. new file locations and import paths.

---

## Troubleshooting

- Ensure all dependencies are installed
- Check `.env` for correct API keys
- If RAG queries fail, rebuild the vector store and verify ChromaDB files

---

## License

MIT License
