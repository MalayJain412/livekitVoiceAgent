package testdata

import _ "embed"

//go:embed change-amelia.ogg
var TestAudioOgg []byte
