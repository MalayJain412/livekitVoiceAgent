This archive contains files moved from the main repo during cleanup on 2025-09-29.

Purpose: keep development-only or downloaded artifacts out of the production tree while preserving them for recovery.


Moved items (done):
- `client-sdk-js-main/`  (downloaded LiveKit JS SDK source)
- `all_code_snippets.txt`

Planned moves (not yet executed):
- `downloaded_package/` (recommended)
- `all_code_snippets_frontend.txt` (recommended)
- `node_modules/` (recommended, large)

Notes:
- `conversations/` and `leads/` were intentionally left in place per user instruction. Do NOT remove these runtime files from the repo unless you intend to sanitize and archive them separately.
- `venv/` is still present in repo root (user chose to keep for now and remove before production).

To execute the remaining moves locally (PowerShell):

```powershell
Move-Item -Path .\downloaded_package -Destination .\archive\cleanup_20250929 -Force
Move-Item -Path .\all_code_snippets_frontend.txt -Destination .\archive\cleanup_20250929 -Force
Move-Item -Path .\node_modules -Destination .\archive\cleanup_20250929 -Force
```

If you want me to run these moves now, confirm and I will perform them.

If you need to restore any item, move it back to the repo root and commit.

2025-09-29 15:56:40 - Automated move: client-sdk-js-main, copilot_tasks, all_code_snippets.txt, custom_plugins moved into this archive. Skipped (already moved or missing): downloaded_package, all_code_snippets_frontend.txt, node_modules (may already be archived).
