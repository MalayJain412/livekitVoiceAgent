Runtime data (moved from repo root):

- conversation and lead JSONs moved here for safekeeping. These files may contain PII and should be stored securely outside of source control.
