# FRIDAY AI: Dummy LiveKit package init
"""
Testing LiveKit package for FRIDAY AI conversation logging system
"""
