# FRIDAY AI: Dummy LiveKit plugins package init
"""
Testing plugins package for FRIDAY AI conversation logging system
"""

__version__ = "0.1.0-testing"
