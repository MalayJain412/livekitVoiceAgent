---
'livekit-client': patch
---

Add video autoplay attributes to PublishVideoCheck
