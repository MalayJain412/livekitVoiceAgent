---
"livekit-client": patch
---

Register online listener in engine's join
