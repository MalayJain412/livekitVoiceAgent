---
"livekit-client": patch
---

Properly clean up event listeners in getNewAudioContext()