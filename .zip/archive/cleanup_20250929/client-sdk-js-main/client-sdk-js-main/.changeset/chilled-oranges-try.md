---
"livekit-client": patch
---

Add preliminary support for data message decryption
