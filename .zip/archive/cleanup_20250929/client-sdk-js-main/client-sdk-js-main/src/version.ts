import { version as v } from '../package.json';

export const version = v;
export const protocolVersion = 16;
