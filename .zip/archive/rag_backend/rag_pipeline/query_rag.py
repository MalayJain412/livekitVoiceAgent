# rag_pipeline/query_rag.py - RAG query system
import os
import logging
from typing import Optional

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_chroma import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate

logger = logging.getLogger(__name__)

# Configuration
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
LLM_MODEL = "gemini-1.5-flash"
TEMPERATURE = 0.3

# Global RAG chain cache
_rag_chain = None
_chroma_dir = None

def initialize_rag_system(chroma_dir: str) -> bool:
    """Initialize the RAG system"""
    global _rag_chain, _chroma_dir
    
    try:
        # Check if vector database exists
        if not os.path.exists(os.path.join(chroma_dir, "chroma.sqlite3")):
            logger.warning(f"Vector database not found at {chroma_dir}")
            return False
        
        # Get Google API key
        google_api_key = os.getenv("GOOGLE_API_KEY")
        if not google_api_key:
            logger.error("GOOGLE_API_KEY not found in environment")
            return False
        
        # Initialize components
        logger.info("Initializing RAG components...")
        
        llm = ChatGoogleGenerativeAI(
            model=LLM_MODEL,
            google_api_key=google_api_key,
            temperature=TEMPERATURE
        )
        
        embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
        
        vectorstore = Chroma(
            persist_directory=chroma_dir,
            embedding_function=embeddings
        )
        
        retriever = vectorstore.as_retriever(
            search_type="mmr",  # Maximal Marginal Relevance
            search_kwargs={"k": 4, "fetch_k": 8}
        )
        
        # System prompt for RAG
        system_prompt = """You are an advanced AI assistant with expertise in understanding and explaining complex information.
Your role is to answer user questions comprehensively using the provided knowledge base context.

Guidelines:
1. Always ground your answers in the provided context, but expand with reasoning, clarification, and related insights.
2. Provide clear, structured, and well-organized responses (use sections, bullet points, or lists where helpful).
3. Be detailed — explain concepts fully instead of giving short or vague replies.
4. Highlight key insights, important details, and actionable information.
5. If something is unclear in the context, infer the most likely explanation and explicitly state your assumptions.
6. If the information truly does not exist in the knowledge base, say: 
   "The available knowledge base does not provide a direct answer to this question," 
   and suggest possible directions or related knowledge.

Context: {context}"""

        qa_prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            ("human", "{input}")
        ])
        
        question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
        _rag_chain = create_retrieval_chain(retriever, question_answer_chain)
        _chroma_dir = chroma_dir
        
        logger.info("RAG system initialized successfully")
        return True
    
    except Exception as e:
        logger.error(f"Error initializing RAG system: {str(e)}")
        return False

async def query_rag_system(query: str, chroma_dir: str) -> str:
    """Query the RAG system"""
    global _rag_chain, _chroma_dir
    
    try:
        # Initialize if needed or if chroma_dir changed
        if _rag_chain is None or _chroma_dir != chroma_dir:
            if not initialize_rag_system(chroma_dir):
                raise Exception("Failed to initialize RAG system")
        
        # Query the system
        logger.info(f"Processing query: {query[:100]}...")
        response = _rag_chain.invoke({"input": query})
        
        answer = response.get("answer", "").strip()
        
        if not answer:
            return "I couldn't generate an answer from the available knowledge base. Please try rephrasing your question."
        
        logger.info(f"Generated answer length: {len(answer)} characters")
        return answer
    
    except Exception as e:
        logger.error(f"Error querying RAG system: {str(e)}")
        raise Exception(f"RAG query failed: {str(e)}")

def reset_rag_system():
    """Reset the RAG system (useful after vector DB rebuild)"""
    global _rag_chain, _chroma_dir
    _rag_chain = None
    _chroma_dir = None
    logger.info("RAG system reset")

if __name__ == "__main__":
    # For standalone testing
    import asyncio
    import sys
    
    if len(sys.argv) > 2:
        query = sys.argv[1]
        chroma_dir = sys.argv[2]
        
        async def test_query():
            try:
                answer = await query_rag_system(query, chroma_dir)
                print(f"Query: {query}")
                print(f"Answer: {answer}")
            except Exception as e:
                print(f"Error: {str(e)}")
        
        asyncio.run(test_query())
    else:
        print("Usage: python query_rag.py '<query>' <chroma_dir>")
