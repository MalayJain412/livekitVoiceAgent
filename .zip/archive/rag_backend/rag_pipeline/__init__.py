# rag_pipeline/__init__.py
"""
RAG Pipeline Package

This package contains modules for building and querying a RAG (Retrieval-Augmented Generation) system.

Modules:
- file_utils: File validation and text extraction from various formats
- build_db: Vector database building and management
- query_rag: RAG query processing and answer generation
"""

__version__ = "1.0.0"
__author__ = "Friday AI Team"

from .file_utils import validate_file, extract_text_from_file, get_all_kb_text
from .build_db import build_vector_store_sync, build_vector_store_async
from .query_rag import query_rag_system, initialize_rag_system, reset_rag_system

__all__ = [
    "validate_file",
    "extract_text_from_file", 
    "get_all_kb_text",
    "build_vector_store_sync",
    "build_vector_store_async",
    "query_rag_system",
    "initialize_rag_system",
    "reset_rag_system"
]
