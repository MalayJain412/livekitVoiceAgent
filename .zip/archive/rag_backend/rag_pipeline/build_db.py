# rag_pipeline/build_db.py - Vector store builder
import os
import logging
from datetime import datetime
from typing import List

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.documents import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

from .file_utils import get_all_kb_text

logger = logging.getLogger(__name__)

# Configuration
MAX_CHUNK_SIZE = 1500
CHUNK_OVERLAP = 200
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

def create_documents_from_text(text: str, source: str = "knowledge_base") -> List[Document]:
    """Convert raw text into LangChain Documents with metadata"""
    metadata = {
        "source": source,
        "timestamp": datetime.now().isoformat()
    }
    return [Document(page_content=text, metadata=metadata)]

def chunk_documents(documents: List[Document]) -> List[Document]:
    """Split text into overlapping chunks for embeddings"""
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=MAX_CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
        add_start_index=True
    )
    chunks = text_splitter.split_documents(documents)
    logger.info(f"Split into {len(chunks)} chunks")
    return chunks

def build_vector_store_sync(kb_dir: str, chroma_dir: str) -> bool:
    """Build vector store synchronously"""
    try:
        logger.info("Starting vector store build process...")
        
        # Extract text from all KB files
        combined_text = get_all_kb_text(kb_dir)
        if not combined_text.strip():
            logger.warning("No text content found in knowledge base files")
            return False
        
        logger.info(f"Combined text length: {len(combined_text)} characters")
        
        # Create documents
        documents = create_documents_from_text(combined_text, kb_dir)
        
        # Chunk documents
        chunks = chunk_documents(documents)
        
        # Initialize embeddings
        logger.info("Initializing embeddings...")
        embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
        
        # Remove existing vector store
        if os.path.exists(chroma_dir):
            import shutil
            shutil.rmtree(chroma_dir)
            logger.info("Removed existing vector store")
        
        # Create new vector store
        logger.info(f"Creating vector store at {chroma_dir}...")
        vectorstore = Chroma.from_documents(
            documents=chunks,
            embedding=embeddings,
            persist_directory=chroma_dir
        )
        
        logger.info("Vector store created successfully")
        return True
    
    except Exception as e:
        logger.error(f"Error building vector store: {str(e)}")
        return False

async def build_vector_store_async(kb_dir: str, chroma_dir: str):
    """Build vector store asynchronously (background task)"""
    global build_status
    
    try:
        # Update build status
        from main import build_status
        build_status["status"] = "building"
        build_status["logs"] = ["Starting build process..."]
        
        success = build_vector_store_sync(kb_dir, chroma_dir)
        
        if success:
            build_status["status"] = "completed"
            build_status["logs"].append("Build completed successfully")
        else:
            build_status["status"] = "failed"
            build_status["logs"].append("Build failed")
        
        build_status["timestamp"] = datetime.now().isoformat()
        
    except Exception as e:
        logger.error(f"Async build error: {str(e)}")
        try:
            from main import build_status
            build_status["status"] = "failed"
            build_status["logs"].append(f"Build failed: {str(e)}")
            build_status["timestamp"] = datetime.now().isoformat()
        except:
            pass

if __name__ == "__main__":
    # For standalone testing
    import sys
    if len(sys.argv) > 2:
        kb_dir = sys.argv[1]
        chroma_dir = sys.argv[2]
        success = build_vector_store_sync(kb_dir, chroma_dir)
        print(f"Build {'successful' if success else 'failed'}")
    else:
        print("Usage: python build_db.py <kb_dir> <chroma_dir>")
