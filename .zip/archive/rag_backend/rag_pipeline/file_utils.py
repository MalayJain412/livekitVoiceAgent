# rag_pipeline/file_utils.py - File validation and text extraction
import os
import json
import logging
from typing import Dict, Any
from fastapi import UploadFile

logger = logging.getLogger(__name__)

# Supported file extensions
SUPPORTED_EXTENSIONS = {".txt", ".json", ".pdf", ".docx"}

def validate_file(file: UploadFile) -> Dict[str, Any]:
    """Validate uploaded file format and content"""
    try:
        # Check file extension
        filename = file.filename.lower()
        ext = os.path.splitext(filename)[1]
        
        if ext not in SUPPORTED_EXTENSIONS:
            return {
                "valid": False,
                "error": f"Unsupported file type. Supported: {', '.join(SUPPORTED_EXTENSIONS)}"
            }
        
        # Check filename
        if not filename or filename.startswith('.'):
            return {
                "valid": False,
                "error": "Invalid filename"
            }
        
        return {"valid": True, "extension": ext}
    
    except Exception as e:
        logger.error(f"File validation error: {str(e)}")
        return {"valid": False, "error": str(e)}

def extract_text_from_file(file_path: str) -> str:
    """Extract text content from various file formats"""
    try:
        ext = os.path.splitext(file_path)[1].lower()
        
        if ext == ".txt":
            return extract_text_from_txt(file_path)
        elif ext == ".json":
            return extract_text_from_json(file_path)
        elif ext == ".pdf":
            return extract_text_from_pdf(file_path)
        elif ext == ".docx":
            return extract_text_from_docx(file_path)
        else:
            raise ValueError(f"Unsupported file extension: {ext}")
    
    except Exception as e:
        logger.error(f"Text extraction error for {file_path}: {str(e)}")
        raise

def extract_text_from_txt(file_path: str) -> str:
    """Extract text from .txt file"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read().strip()

def extract_text_from_json(file_path: str) -> str:
    """Extract text from .json file"""
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Convert JSON to searchable text
    def json_to_text(obj, prefix=""):
        text_parts = []
        
        if isinstance(obj, dict):
            for key, value in obj.items():
                if isinstance(value, (dict, list)):
                    text_parts.append(json_to_text(value, f"{prefix}{key}: "))
                else:
                    text_parts.append(f"{prefix}{key}: {str(value)}")
        
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                text_parts.append(json_to_text(item, f"{prefix}[{i}] "))
        
        else:
            text_parts.append(f"{prefix}{str(obj)}")
        
        return "\n".join(text_parts)
    
    return json_to_text(data)

def extract_text_from_pdf(file_path: str) -> str:
    """Extract text from .pdf file"""
    try:
        import pdfplumber
        
        text_content = []
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    text_content.append(text)
        
        return "\n".join(text_content).strip()
    
    except ImportError:
        # Fallback to PyPDF2 if pdfplumber not available
        try:
            import PyPDF2
            
            text_content = []
            with open(file_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    text = page.extract_text()
                    if text:
                        text_content.append(text)
            
            return "\n".join(text_content).strip()
        
        except ImportError:
            raise ImportError("Please install pdfplumber or PyPDF2 for PDF support")

def extract_text_from_docx(file_path: str) -> str:
    """Extract text from .docx file"""
    try:
        from docx import Document
        
        doc = Document(file_path)
        text_content = []
        
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():
                text_content.append(paragraph.text)
        
        return "\n".join(text_content).strip()
    
    except ImportError:
        raise ImportError("Please install python-docx for Word document support")

def get_all_kb_text(kb_dir: str) -> str:
    """Extract and combine text from all knowledge base files"""
    combined_text = []
    
    for filename in os.listdir(kb_dir):
        file_path = os.path.join(kb_dir, filename)
        if os.path.isfile(file_path):
            try:
                ext = os.path.splitext(filename)[1].lower()
                if ext in SUPPORTED_EXTENSIONS:
                    text = extract_text_from_file(file_path)
                    if text:
                        combined_text.append(f"=== {filename} ===\n{text}\n")
                        logger.info(f"Extracted text from {filename}: {len(text)} characters")
            except Exception as e:
                logger.error(f"Failed to extract text from {filename}: {str(e)}")
    
    return "\n".join(combined_text)
