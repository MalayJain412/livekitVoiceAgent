# RAG Backend API

A standalone FastAPI backend for knowledge base management and RAG (Retrieval-Augmented Generation) queries.

## Features

- **File Upload**: Support for `.txt`, `.json`, `.pdf`, `.docx` files
- **Knowledge Base Management**: List, delete, and manage knowledge files
- **Vector Database**: Automatic building and updating of ChromaDB vector store
- **RAG Queries**: Advanced query processing with context retrieval and LLM generation
- **Async Processing**: Background tasks for database building
- **Docker Ready**: Easy deployment with Docker

## Quick Start

### Local Development

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure environment:**
   ```bash
   cp .env.example .env
   # Edit .env with your API keys
   ```

3. **Run the server:**
   ```bash
   uvicorn main:app --reload
   ```

4. **Access API docs:**
   - API: http://localhost:8000
   - Docs: http://localhost:8000/docs

### Docker Deployment

1. **Build image:**
   ```bash
   docker build -t rag-backend .
   ```

2. **Run container:**
   ```bash
   docker run -p 8000:8000 --env-file .env rag-backend
   ```

## API Endpoints

| Endpoint         | Method | Description                          |
|------------------|--------|--------------------------------------|
| `/`              | GET    | Health check                         |
| `/upload`        | POST   | Upload knowledge base file           |
| `/files`         | GET    | List all knowledge base files        |
| `/files/{name}`  | DELETE | Delete a knowledge base file         |
| `/build_db`      | POST   | Build/rebuild vector database        |
| `/build_status`  | GET    | Get build status and logs            |
| `/query`         | POST   | Query the RAG system                 |

## Usage Examples

### Upload a file
```bash
curl -X POST "http://localhost:8000/upload" \
     -H "Content-Type: multipart/form-data" \
     -F "file=@knowledge.txt"
```

### Build vector database
```bash
curl -X POST "http://localhost:8000/build_db"
```

### Query the system
```bash
curl -X POST "http://localhost:8000/query" \
     -H "Content-Type: application/json" \
     -d '{"query": "What is machine learning?"}'
```

## Configuration

Environment variables in `.env`:

- `GOOGLE_API_KEY`: Google Gemini API key
- `EMBEDDING_MODEL`: HuggingFace embedding model
- `LLM_MODEL`: Google Gemini model name
- `MAX_CHUNK_SIZE`: Text chunk size for vectorization
- `CHUNK_OVERLAP`: Overlap between text chunks

## Development

### Project Structure
```
rag_backend/
├── main.py                # FastAPI application
├── rag_pipeline/          # RAG processing modules
│   ├── file_utils.py      # File validation and text extraction
│   ├── build_db.py        # Vector database building
│   ├── query_rag.py       # RAG query processing
│   └── __init__.py
├── knowledge_base/        # Uploaded files
├── chroma_db/             # Vector database
├── logs/                  # Application logs
├── requirements.txt
├── Dockerfile
└── .env
```

### Adding New File Types

1. Update `SUPPORTED_EXTENSIONS` in `file_utils.py`
2. Add extraction function in `file_utils.py`
3. Update validation logic

### Customizing RAG Pipeline

- **Embeddings**: Modify `EMBEDDING_MODEL` in `query_rag.py`
- **LLM**: Change `LLM_MODEL` and prompts in `query_rag.py`
- **Chunking**: Adjust `MAX_CHUNK_SIZE` and `CHUNK_OVERLAP` in `build_db.py`
- **Retrieval**: Modify retriever settings in `query_rag.py`

## Integration

### With LiveKit/Friday AI

Update `tools.py` to call the RAG backend:

```python
import requests

async def query_rag_backend(query: str) -> str:
    response = requests.post(
        "http://rag-backend:8000/query",
        json={"query": query}
    )
    if response.status_code == 200:
        return response.json()["data"]["answer"]
    else:
        return "RAG service unavailable"
```

## License

MIT License
