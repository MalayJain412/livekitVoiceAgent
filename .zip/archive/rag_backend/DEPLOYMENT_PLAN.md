# RAG Backend - Complete Deployment & Testing Plan

## 🚀 **Quick Start Guide**

### 1. **Install Dependencies**
```bash
cd rag_backend
pip install python-multipart
pip install -r requirements.txt
```

### 2. **Start the Server**
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### 3. **Access API**
- **API Base:** http://localhost:8000
- **Interactive Docs:** http://localhost:8000/docs
- **OpenAPI Schema:** http://localhost:8000/openapi.json

---

## 📋 **Complete Testing Workflow**

### **Step 1: Health Check**
```bash
curl http://localhost:8000/
```
**Expected Response:**
```json
{
  "message": "RAG Backend API is running",
  "version": "1.0.0"
}
```

### **Step 2: Upload Knowledge Files**
```bash
# Upload a text file
curl -X POST "http://localhost:8000/upload" \
     -H "Content-Type: multipart/form-data" \
     -F "file=@sample_knowledge.txt"

# Upload a JSON file
curl -X POST "http://localhost:8000/upload" \
     -H "Content-Type: multipart/form-data" \
     -F "file=@knowledge.json"
```

### **Step 3: List Uploaded Files**
```bash
curl http://localhost:8000/files
```
**Expected Response:**
```json
{
  "status": "success",
  "data": {
    "files": [
      {
        "filename": "sample_knowledge.txt",
        "size": 1024,
        "modified": "2025-08-28T13:30:00"
      }
    ],
    "count": 1
  }
}
```

### **Step 4: Build Vector Database**
```bash
curl -X POST "http://localhost:8000/build_db"
```
**Expected Response:**
```json
{
  "status": "success",
  "data": {
    "message": "Vector database build started",
    "build_id": "2025-08-28T13:30:00"
  }
}
```

### **Step 5: Check Build Status**
```bash
curl http://localhost:8000/build_status
```
**Expected Response:**
```json
{
  "status": "success",
  "data": {
    "status": "completed",
    "logs": ["Starting build process...", "Build completed successfully"],
    "timestamp": "2025-08-28T13:30:00"
  }
}
```

### **Step 6: Query the RAG System**
```bash
curl -X POST "http://localhost:8000/query" \
     -H "Content-Type: application/json" \
     -d '{"query": "What is machine learning?"}'
```
**Expected Response:**
```json
{
  "status": "success",
  "data": {
    "query": "What is machine learning?",
    "answer": "Machine learning is a subset of artificial intelligence...",
    "timestamp": "2025-08-28T13:30:00"
  }
}
```

### **Step 7: Delete Files (Optional)**
```bash
curl -X DELETE "http://localhost:8000/files/sample_knowledge.txt"
```

---

## 🐳 **Docker Deployment**

### **Build Image**
```bash
docker build -t rag-backend:latest .
```

### **Run Container**
```bash
docker run -d \
  --name rag-backend \
  -p 8000:8000 \
  --env-file .env \
  -v $(pwd)/knowledge_base:/app/knowledge_base \
  -v $(pwd)/chroma_db:/app/chroma_db \
  -v $(pwd)/logs:/app/logs \
  rag-backend:latest
```

### **Check Container Status**
```bash
docker ps
docker logs rag-backend
```

---

## ☁️ **Cloud Deployment Options**

### **1. AWS ECS/Fargate**
```yaml
# docker-compose.yml for AWS
version: '3.8'
services:
  rag-backend:
    image: rag-backend:latest
    ports:
      - "8000:8000"
    environment:
      - GOOGLE_API_KEY=${GOOGLE_API_KEY}
    volumes:
      - rag-data:/app/knowledge_base
      - rag-db:/app/chroma_db
volumes:
  rag-data:
  rag-db:
```

### **2. Google Cloud Run**
```bash
# Build and push to Container Registry
docker tag rag-backend:latest gcr.io/PROJECT_ID/rag-backend
docker push gcr.io/PROJECT_ID/rag-backend

# Deploy to Cloud Run
gcloud run deploy rag-backend \
  --image gcr.io/PROJECT_ID/rag-backend \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars GOOGLE_API_KEY=YOUR_KEY
```

### **3. Azure Container Instances**
```bash
az container create \
  --resource-group myResourceGroup \
  --name rag-backend \
  --image rag-backend:latest \
  --dns-name-label rag-backend-unique \
  --ports 8000 \
  --environment-variables GOOGLE_API_KEY=YOUR_KEY
```

---

## 🔧 **Configuration Guide**

### **Environment Variables (.env)**
```bash
# Required
GOOGLE_API_KEY=your_google_api_key_here

# Optional (with defaults)
API_HOST=0.0.0.0
API_PORT=8000
EMBEDDING_MODEL=all-MiniLM-L6-v2
LLM_MODEL=gemini-1.5-flash
LLM_TEMPERATURE=0.3
MAX_CHUNK_SIZE=1500
CHUNK_OVERLAP=200
LOG_LEVEL=INFO
```

### **Production Recommendations**
- Use multiple Google API keys for rate limiting
- Set up proper logging (e.g., CloudWatch, Stackdriver)
- Configure CORS for specific domains only
- Use persistent volumes for knowledge_base and chroma_db
- Set up health checks and monitoring
- Enable HTTPS with SSL certificates

---

## 🧪 **Test Data Examples**

### **Sample Text File (sample_knowledge.txt)**
```
Artificial Intelligence Overview

Machine learning is a subset of artificial intelligence (AI) that focuses on algorithms that can learn and make decisions from data without being explicitly programmed for every scenario.

Key Types of Machine Learning:
1. Supervised Learning - Uses labeled training data
2. Unsupervised Learning - Finds patterns in unlabeled data  
3. Reinforcement Learning - Learns through trial and error

Applications include:
- Computer vision and image recognition
- Natural language processing
- Recommendation systems
- Autonomous vehicles
- Medical diagnosis
```

### **Sample JSON File (knowledge.json)**
```json
{
  "company": "Triotech Bizserve",
  "products": [
    {
      "name": "Justtawk",
      "description": "AI-powered Virtual Call Center with intelligent voice bots",
      "features": ["Voice Recognition", "Real-time Analytics", "Multi-language Support"]
    },
    {
      "name": "Convoze", 
      "description": "Conversation Analytics Platform",
      "features": ["Sentiment Analysis", "Call Scoring", "Performance Insights"]
    }
  ],
  "faqs": [
    {
      "question": "What is AI-powered customer service?",
      "answer": "AI-powered customer service uses artificial intelligence to automate and enhance customer interactions through chatbots, voice assistants, and analytics."
    }
  ]
}
```

---

## 🔌 **Integration with LiveKit/Friday AI**

### **Update tools.py**
```python
import requests
import logging

RAG_BACKEND_URL = "http://localhost:8000"  # or your deployed URL

async def query_rag_backend(query: str) -> str:
    """Query the standalone RAG backend"""
    try:
        response = requests.post(
            f"{RAG_BACKEND_URL}/query",
            json={"query": query},
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            return data["data"]["answer"]
        else:
            logging.error(f"RAG backend error: {response.status_code}")
            return "RAG service is temporarily unavailable."
            
    except Exception as e:
        logging.error(f"Failed to query RAG backend: {str(e)}")
        return "Unable to process detailed queries at the moment."

# Update your existing triotech_info function
@function_tool()
async def triotech_info(query: str) -> str:
    """Updated hybrid function using RAG backend"""
    # ... existing JSON logic ...
    
    if is_detailed_query:
        # Use RAG backend instead of local RAG
        rag_result = await query_rag_backend(query)
        if rag_result and "temporarily unavailable" not in rag_result:
            return rag_result
    
    # ... rest of function ...
```

---

## 📊 **Monitoring & Maintenance**

### **Health Monitoring**
```bash
# Check API health
curl http://localhost:8000/

# Monitor logs
tail -f logs/app.log

# Check build status
curl http://localhost:8000/build_status
```

### **Performance Tuning**
- Adjust `MAX_CHUNK_SIZE` and `CHUNK_OVERLAP` based on your content
- Use different embedding models for different languages
- Configure retrieval parameters (`k`, `fetch_k`) based on accuracy needs
- Scale horizontally with load balancers for high traffic

### **Backup Strategy**
- Backup `knowledge_base/` folder regularly
- Backup `chroma_db/` folder (or rebuild from knowledge_base)
- Store environment variables securely
- Version control your knowledge files

---

## 🚨 **Troubleshooting**

### **Common Issues**
1. **Import errors:** Install missing packages from requirements.txt
2. **API key errors:** Check GOOGLE_API_KEY in .env
3. **File upload fails:** Ensure python-multipart is installed
4. **Build fails:** Check logs for file processing errors
5. **Query fails:** Verify vector database exists and is built

### **Debug Commands**
```bash
# Check package installations
pip list | grep -E "(fastapi|langchain|chromadb)"

# Test vector database directly
python -c "
import os
from langchain_chroma import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

embeddings = HuggingFaceEmbeddings(model_name='all-MiniLM-L6-v2')
if os.path.exists('chroma_db/chroma.sqlite3'):
    vectorstore = Chroma(persist_directory='chroma_db', embedding_function=embeddings)
    print(f'Vector store loaded: {vectorstore._collection.count()} documents')
else:
    print('Vector database not found')
"
```

---

**This plan provides everything needed to deploy, test, and integrate the RAG backend independently. Copy this document for your testing environment!** 🎯
