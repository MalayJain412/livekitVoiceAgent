# main.py - FastAPI RAG Backend
import os
import json
import logging
from typing import List
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from rag_pipeline.file_utils import validate_file, extract_text_from_file
from rag_pipeline.build_db import build_vector_store_async
from rag_pipeline.query_rag import query_rag_system

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="RAG Backend API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Directories
KB_DIR = "knowledge_base"
CHROMA_DIR = "chroma_db"
LOGS_DIR = "logs"

# Ensure directories exist
os.makedirs(KB_DIR, exist_ok=True)
os.makedirs(CHROMA_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

# Pydantic models
class QueryRequest(BaseModel):
    query: str

class APIResponse(BaseModel):
    status: str
    data: dict = None
    error: str = None

# Global build status
build_status = {"status": "idle", "logs": [], "timestamp": None}

@app.get("/")
def root():
    """Health check endpoint"""
    return {"message": "RAG Backend API is running", "version": "1.0.0"}

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    """Upload knowledge base file (.txt, .json, .pdf, .docx)"""
    try:
        # Validate file
        validation_result = validate_file(file)
        if not validation_result["valid"]:
            raise HTTPException(status_code=400, detail=validation_result["error"])
        
        # Save file
        file_path = os.path.join(KB_DIR, file.filename)
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        logger.info(f"File uploaded successfully: {file.filename}")
        return APIResponse(
            status="success",
            data={"filename": file.filename, "size": len(content)}
        )
    
    except Exception as e:
        logger.error(f"Upload error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/files")
def list_files():
    """List all knowledge base files"""
    try:
        files = []
        for filename in os.listdir(KB_DIR):
            file_path = os.path.join(KB_DIR, filename)
            if os.path.isfile(file_path):
                stat = os.stat(file_path)
                files.append({
                    "filename": filename,
                    "size": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                })
        
        return APIResponse(
            status="success",
            data={"files": files, "count": len(files)}
        )
    
    except Exception as e:
        logger.error(f"List files error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/files/{filename}")
def delete_file(filename: str):
    """Delete a knowledge base file"""
    try:
        file_path = os.path.join(KB_DIR, filename)
        if not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail="File not found")
        
        os.remove(file_path)
        logger.info(f"File deleted: {filename}")
        
        return APIResponse(
            status="success",
            data={"filename": filename, "action": "deleted"}
        )
    
    except Exception as e:
        logger.error(f"Delete error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/build_db")
async def build_database(background_tasks: BackgroundTasks):
    """Rebuild vector database from all knowledge base files"""
    try:
        global build_status
        
        if build_status["status"] == "building":
            return APIResponse(
                status="info",
                data={"message": "Build already in progress"}
            )
        
        # Start background build
        background_tasks.add_task(build_vector_store_async, KB_DIR, CHROMA_DIR)
        
        build_status = {
            "status": "building",
            "logs": ["Build started"],
            "timestamp": datetime.now().isoformat()
        }
        
        return APIResponse(
            status="success",
            data={"message": "Vector database build started", "build_id": build_status["timestamp"]}
        )
    
    except Exception as e:
        logger.error(f"Build DB error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/build_status")
def get_build_status():
    """Get current build status and logs"""
    return APIResponse(
        status="success",
        data=build_status
    )

@app.post("/query")
async def query_rag(request: QueryRequest):
    """Query the RAG system"""
    try:
        if not request.query.strip():
            raise HTTPException(status_code=400, detail="Query cannot be empty")
        
        # Check if vector database exists
        if not os.path.exists(os.path.join(CHROMA_DIR, "chroma.sqlite3")):
            raise HTTPException(
                status_code=404, 
                detail="Vector database not found. Please build the database first."
            )
        
        # Query RAG system
        answer = await query_rag_system(request.query, CHROMA_DIR)
        
        logger.info(f"Query processed: {request.query[:50]}...")
        
        return APIResponse(
            status="success",
            data={
                "query": request.query,
                "answer": answer,
                "timestamp": datetime.now().isoformat()
            }
        )
    
    except Exception as e:
        logger.error(f"Query error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
