# Friday AI — Copilot / Agent Instructions

Purpose: short, targeted guidance so an AI coding agent can be productive in this repository immediately.

## Quick start (PowerShell)

```powershell
# install deps
pip install -r requirements.txt
pip install -r model/requirements.txt

# build vector DB (required for RAG)
python model/build_db.py

# run voice agent
python cagent.py

# run RAG web API
python model/runapi.py

# run tests (project uses simple python test scripts)
python test_triotech_assistant.py
python test_dummy_plugins.py
python test_lead_detection.py
```

## What to read first (fast path)
- `cagent.py` — entrypoint: sets up conversation logging and AgentSession.
- `tools.py` — core function tools (triotech_info, create_lead, detect_lead_intent). Primary place for business logic.
- `prompts.py` — agent/system prompts (Hinglish + lead capture rules).
- `config.py` — conversation log path helpers and helpers used across tests/plugins.
- `model/build_db.py` and `model/runapi.py` — RAG build & runtime (Chroma DB, embeddings, API key rotation).
- `backup_plugin_modifications/` — modified LiveKit plugin stubs (`google_llm_modified.py`, `cartesia_tts_modified.py`) and `docker_scripts/` for applying them.

## Key repository conventions (must follow exactly)
- User-facing language: Hinglish (brief Hindi+English). Lead confirmations/prompts are in Hinglish. See `prompts.py` for exact wording.
- Lead storage: Lead JSON fields MUST be English (`name`, `email`, `company`, `interest`, `phone`, `budget`) — used for CRM downstream.
- Tools: all user-facing tools follow the decorator pattern:
  `@function_tool()`
  ```instructions
  # Friday AI — Copilot / Agent Instructions (concise)

  Purpose: get an AI coding agent productive quickly. Read the short path below and use file references verbatim.

  Quick start (PowerShell)
  ```powershell
  pip install -r requirements.txt
  pip install -r model/requirements.txt
  python model/build_db.py      # rebuild RAG after knowledge edits
  python cagent.py              # run agent
  python model/runapi.py        # optional RAG API
  python test_triotech_assistant.py
  python test_dummy_plugins.py
  python test_lead_detection.py
  ```

  Read first (fast path)
  - `cagent.py` — entrypoint: AgentSession, plugin wiring, conversation logging
  - `tools.py` — business tools: `triotech_info`, `create_lead`, `detect_lead_intent` (use `@function_tool()` pattern)
  - `prompts.py` — Hinglish system prompts and lead capture wording
  - `config.py` — paths and conversation/lead save helpers
  - `model/build_db.py`, `model/runapi.py` — RAG build + runtime (Chroma DB under `model/chroma_db/`)

  Project-specific conventions (must follow)
  - Language: user-facing strings must be Hinglish; lead JSON keys MUST be English (`name,email,company,interest,phone,budget`).
  - Tools: exported as async string-returning functions with `@function_tool()` decorator.
  - Conversation log name: `conversations/conversation_YYYYMMDD_HHMMSS.json` (use `config.setup_conversation_log()`).
  - RAG chunk settings: chunk_size=1500, overlap=200 (see `model/build_db.py`).

  Key patterns & integration points
  - Hybrid answer flow in `tools.triotech_info`: fast JSON lookup in `data/` → fallback to RAG via `model/runapi.py` for deep queries (keywords: features/how to/api/integrate).
  - Lead flow: `detect_lead_intent()` → `create_lead()` (validate → sanitize → write `leads/lead_YYYYMMDD_HHMMSS.json`).
  - Plugins: `backup_plugin_modifications/` holds patched plugin stubs; `docker_scripts/apply_modifications.py` and `verify_modifications.py` apply/verify patches.
  - LiveKit: token handling and bot join flows are critical (frontend token route: `friday-frontend/src/app/api/livekit/token/route.ts`).
  - RAG runtime: `model/runapi.py` handles embeddings, key rotation, and queries to `model/chroma_db/`.

  Debugging & tests
  - Tests are small Python scripts (not pytest fixtures) — run them directly.
  - To inspect current conversation log path: `python -c "import config; print(config.get_conversation_log_path())"`.
  - After editing knowledge files, run `python model/build_db.py` to rebuild embeddings.

  Security & operations notes
  - Keep `LIVEKIT_API_SECRET` only where tokens are minted; prefer backend as canonical token authority.
  - Leads and conversations contain PII — protect filesystem or move to a secure DB; prefer atomic writes or file locks for concurrent processes.

  When changing behavior
  - Add unit tests that exercise the `@function_tool()` functions and the lead creation/validation paths.
  - If you change RAG knowledge, rebuild DB and add a small integration test hitting `model/runapi.py`.

  Files to inspect when working end-to-end
  - Frontend: `friday-frontend/src/app/api/livekit/token/route.ts`, `friday-frontend/src/components/voice-assistant.tsx`
  - Backend: `cagent.py`, `generate_livekit_token.py`, `tools.py`, `model/runapi.py`, `backup_plugin_modifications/`

  If you want a deeper expansion (pydantic schemas for leads, CI workflow, or PNG exports of diagrams), tell me which and I’ll implement it.
  ```
When in doubt: prefer the backend as the canonical token service and add a read-only backend endpoint to surface leads if the frontend needs them.
