import sys
from azure.storage.blob import BlobServiceClient
from config import CONNECTION_STRING, CONTAINER_NAME # Import from our config file

def list_files():
    try:
        # Connect to Azure
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(CONTAINER_NAME)

        print(f"Listing all files in container '{CONTAINER_NAME}':\n")
        
        blob_list = container_client.list_blobs()
        count = 0
        for blob in blob_list:
            # Format size to be more readable
            size_in_kb = blob.size / 1024
            print(f"  - {blob.name}  (Size: {size_in_kb:.2f} KB)")
            count += 1
        
        if count == 0:
            print("  (Container is empty)")
        
        print(f"\n✅ Found {count} file(s).")

    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")

if __name__ == "__main__":
    list_files()