import sys
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError
from config import CONNECTION_STRING, CONTAINER_NAME # Import from our config file

def download_file(blob_name, local_save_path):
    try:
        # Connect to Azure
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)

        print(f"Connecting to storage account 'xenystorage'...")
        print(f"Attempting to download '{blob_name}' from container '{CONTAINER_NAME}'...")

        # Open the local file in binary write mode and download
        with open(local_save_path, "wb") as download_file:
            download_file.write(blob_client.download_blob().readall())

        print(f"✅ Success! File saved locally as '{local_save_path}'.")

    except ResourceNotFoundError:
        print(f"❌ ERROR: Blob '{blob_name}' not found in container '{CONTAINER_NAME}'.")
        print("Please check the filename and try again.")
    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")

if __name__ == "__main__":
    # Check if two arguments were provided
    if len(sys.argv) < 3:
        print("Usage: python download_wav.py <blob_name_in_azure> <local_path_to_save>")
        print("Example: python download_wav.py my-recording.wav downloaded_file.wav")
        sys.exit(1)
        
    blob_to_download = sys.argv[1]
    local_path = sys.argv[2]
    download_file(blob_to_download, local_path)