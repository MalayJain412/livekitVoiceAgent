# config.py
# Store your credentials here to share across scripts.
# DO NOT commit this file to a public git repository.

CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=xenystorage;AccountKey=murwg3qmth1OLRBPOZo+2NrwcJg8RgkGmlnzew48ijvJ51NPOylSmBawDY4cJmqr1s03+vf1+K9t+AStwFrz2A==;EndpointSuffix=core.windows.net"
CONTAINER_NAME = "livekit-recordings"