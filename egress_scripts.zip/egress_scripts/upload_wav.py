import sys
import os
from azure.storage.blob import BlobServiceClient
from config import CONNECTION_STRING, CONTAINER_NAME # Import from our new config file

def upload_file(local_file_path):
    try:
        # Check if the file exists locally
        if not os.path.exists(local_file_path):
            print(f"❌ ERROR: File not found at '{local_file_path}'")
            return

        # Use the local filename as the blob name in Azure
        blob_name = os.path.basename(local_file_path)

        # Connect to Azure
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)

        print(f"Connecting to storage account 'xenystorage'...")
        print(f"Uploading '{local_file_path}' to container '{CONTAINER_NAME}' as '{blob_name}'...")

        # Open the local file in binary read mode and upload
        with open(local_file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)

        print(f"✅ Success! File '{blob_name}' was uploaded.")

    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")

if __name__ == "__main__":
    # Check if a filename was provided as an argument
    if len(sys.argv) < 2:
        print("Usage: python upload_wav.py <path_to_your_wav_file>")
        sys.exit(1)
        
    file_to_upload = sys.argv[1]
    upload_file(file_to_upload)