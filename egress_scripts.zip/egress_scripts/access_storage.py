import os
import sys
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError

# --- Your Credentials (same as before) ---
CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=xenystorage;AccountKey=murwg3qmth1OLRBPOZo+2NrwcJg8RgkGmlnzew48ijvJ51NPOylSmBawDY4cJmqr1s03+vf1+K9t+AStwFrz2A==;EndpointSuffix=core.windows.net"
CONTAINER_NAME = "livekit-recordings"
# ----------------------------------------

# Define file names for our test
LOCAL_FILE_TO_UPLOAD = "sample_upload.txt"
BLOB_NAME_IN_AZURE = "my-test-recording.txt" # The name we'll give the file in Azure
LOCAL_FILE_TO_DOWNLOAD = "sample_download.txt"

def main_operations():
    try:
        # --- Connect to Azure Storage ---
        print(f"Connecting to storage account 'xenystorage'...")
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        
        # Get a client to interact with the specific container
        container_client = blob_service_client.get_container_client(CONTAINER_NAME)
        print(f"Connected to container '{CONTAINER_NAME}'.\n")


        # === 1. UPLOAD ===
        print(f"--- 1. UPLOAD Operation ---")
        
        # Create a dummy local file to upload
        print(f"Creating dummy file '{LOCAL_FILE_TO_UPLOAD}'...")
        with open(LOCAL_FILE_TO_UPLOAD, "w") as f:
            f.write("This is a test file for the LiveKit recording storage.")
        
        # Get a client for the specific blob (file)
        blob_client = container_client.get_blob_client(BLOB_NAME_IN_AZURE)
        
        print(f"Uploading '{LOCAL_FILE_TO_UPLOAD}' to Azure as '{BLOB_NAME_IN_AZURE}'...")
        with open(LOCAL_FILE_TO_UPLOAD, "rb") as data:
            blob_client.upload_blob(data, overwrite=True) # overwrite=True allows rerunning
        print(f"✅ Upload successful.\n")


        # === 2. LIST ===
        print(f"--- 2. LIST Operation ---")
        print(f"Listing all blobs in container '{CONTAINER_NAME}':")
        
        blob_list = container_client.list_blobs()
        count = 0
        for blob in blob_list:
            print(f"  - {blob.name} (Size: {blob.size} bytes)")
            count += 1
        
        if count == 0:
            print("  - Container is empty.")
        print(f"✅ List operation complete.\n")


        # === 3. DOWNLOAD ===
        print(f"--- 3. DOWNLOAD Operation ---")
        print(f"Downloading '{BLOB_NAME_IN_AZURE}' to '{LOCAL_FILE_TO_DOWNLOAD}'...")

        # Get the blob client again (or reuse the one from upload)
        blob_to_download = container_client.get_blob_client(BLOB_NAME_IN_AZURE)

        with open(LOCAL_FILE_TO_DOWNLOAD, "wb") as download_file:
            download_file.write(blob_to_download.download_blob().readall())
            
        print(f"✅ Download successful. Check for '{LOCAL_FILE_TO_DOWNLOAD}'.\n")


        # === 4. CLEANUP (Optional) ===
        print(f"--- 4. CLEANUP Operation ---")
        print(f"Deleting local files '{LOCAL_FILE_TO_UPLOAD}' and '{LOCAL_FILE_TO_DOWNLOAD}'...")
        os.remove(LOCAL_FILE_TO_UPLOAD)
        os.remove(LOCAL_FILE_TO_DOWNLOAD)
        print(f"✅ Cleanup complete.")


    except ImportError:
        print("❌ ERROR: 'azure-storage-blob' library not found.")
        print("Please install it first by running: pip install azure-storage-blob")
        sys.exit(1)
        
    except ResourceNotFoundError:
        print(f"❌ ERROR: The container '{CONTAINER_NAME}' was not found.")
        print("Please run the 'make_storage.py' script first.")
        sys.exit(1)
        
    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main_operations()