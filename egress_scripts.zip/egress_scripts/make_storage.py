import sys
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceExistsError

# --- Your Credentials ---
# DO NOT share this connection string publicly.
CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=xenystorage;AccountKey=murwg3qmth1OLRBPOZo+2NrwcJg8RgkGmlnzew48ijvJ51NPOylSmBawDY4cJmqr1s03+vf1+K9t+AStwFrz2A==;EndpointSuffix=core.windows.net"
CONTAINER_NAME = "livekit-recordings"
# --------------------------

def create_container():
    try:
        # Instantiate the BlobServiceClient from the connection string
        print(f"Connecting to storage account 'xenystorage'...")
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)

        # Attempt to create the container
        print(f"Attempting to create container '{CONTAINER_NAME}'...")
        blob_service_client.create_container(CONTAINER_NAME)
        
        print(f"✅ Success! Container '{CONTAINER_NAME}' was created.")

    except ResourceExistsError:
        # This is not an error; it just means the container is already there.
        print(f"ℹ️  Info: Container '{CONTAINER_NAME}' already exists.")

    except ImportError:
        print("❌ ERROR: 'azure-storage-blob' library not found.")
        print("Please install it first by running:")
        print("pip install azure-storage-blob")
        sys.exit(1) # Exit with an error code

    except ValueError as e:
        print(f"❌ ERROR: Invalid connection string. Please double-check it.")
        print(f"   Details: {e}")
        sys.exit(1)

    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")
        print("\nPlease check your connection string, account name/key, and network access.")
        sys.exit(1)

if __name__ == "__main__":
    create_container()